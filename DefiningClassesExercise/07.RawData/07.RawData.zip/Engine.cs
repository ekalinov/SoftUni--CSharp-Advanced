﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _07.RawData
{
    internal class Engine
    {
        public int Speed { get; set; }
        public int Power { get; set; }

    }
}
