﻿using System;

namespace CarManufacturer
{
    public class StartUp
    {
        static void Main(string[] args)
        {

            Car car = new Car();

            car.Make = "BMW";
            car.Model = "x2";
            car.Year = 2015;


        }
    }
}
